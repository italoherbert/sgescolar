
class PessoaDetalhes {
	
}