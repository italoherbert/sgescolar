
para implantar a aplicação, copie o conteúdo da pasta "sisescolar-0.0.1-SNAPSHOT" para a pasta "ROOT" de 
"webapps" do TOMCAT.

Agora, siga os passos para criar o componente "escola-form", conforme detalhado no PDF: "COMPONENTE_ESCOLA-FORM.PDF"

Caso tenha alguma dúvida sobre o passo a passo, leia a sessão sobre o "FRONTEND" DO ARQUIVO: "DOC.PDF"